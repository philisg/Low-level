#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "efm32gg.h"
#include "Sound.c"



void DAC_(int data);// sends data to DAC
void EFFECT_SPACE_GUN();
void EFFECT_SPACE_JUMP();
void EFFECT();
int PLAY_SONG1();
int PLAY_SONG2();
int PLAY_SONG3();
int PLAY_SONG4();
int PLAY_SONG5();
int PLAY_SONG6();
int PLAY_SONG7();
int PLAY_SONG8();



/*
 * TIMER1 interrupt handler 
 */
int i = 0;
int k = 0;
int n = 0;
int note = 0;
int count_note = 0;
int period = 44000/3;//Sets how long to play a note
void __attribute__ ((interrupt)) TIMER1_IRQHandler()
{

	/*
	 * TODO feed new samples to the DAC remember to clear the pending
	 * interrupt by writing 1 to TIMER1_IFC 
	 */
	 *TIMER1_IFC = 1; // clears the intterupt flag
	 
	 *GPIO_PA_DOUT = (*GPIO_PC_DIN << 8);
		switch(n){
			case 0:
				EFFECT_SPACE_JUMP();
			break;
			case 1:
				EFFECT_SPACE_GUN();
			break;
			case 2:
				EFFECT();
			break;
			case 3:
				PLAY_SONG4();
			break;
			case 4:
				PLAY_SONG5();
			break;
			case 5:
				PLAY_SONG6();
			break;
			case 6:
				PLAY_SONG7();
			break;
			case 7:
				PLAY_SONG8();
			break;
			
			}
}

/*
 * GPIO even pin interrupt handler 
 */
 
void __attribute__ ((interrupt)) GPIO_EVEN_IRQHandler()
{
	/*
	 * TODO handle button pressed event, remember to clear pending
	 * interrupt 
	 */
	 *SCR = 0;//makes sure the microcontroller does not go to sleep between timer interrupt.
	 *GPIO_IFC = *GPIO_IF; //clear interrupt flag
	 *TIMER1_CMD = 1; //start timer
	 	if(*GPIO_PC_DIN == 0b11111110)
		{
			n = 0;
			note = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111101)
		{
			n = 1;	
			note = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111011)
		{	
			n = 2;
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11110111)
		{	
			n = 3;	
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11101111)
		{
			n = 4;	
			note = 0;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11011111)
		{
			n = 5;	
			note = 0;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b10111111)
		{	
			n = 6;
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b01111111)
		{	
			n = 7;
			note = 0;		
			count_note = 0;
		}
}

/*
 * GPIO odd pin interrupt handler 
 */
void __attribute__ ((interrupt)) GPIO_ODD_IRQHandler()
{
	/*
	 * TODO handle button pressed event, remember to clear pending
	 * interrupt 
	 */
	 *SCR = 0;
	 *GPIO_IFC = *GPIO_IF; //clear interrupt flag
	 *TIMER1_CMD = 1; //start timer
	 	if(*GPIO_PC_DIN == 0b11111110)
		{
			n = 0;
			note = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111101)
		{
			n = 1;	
			note = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111011)
		{	
			n = 2;
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11110111)
		{	
			n = 3;	
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11101111)
		{
			n = 4;	
			note = 0;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11011111)
		{
			n = 5;	
			note = 0;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b10111111)
		{	
			n = 6;
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b01111111)
		{	
			n = 7;
			note = 0;		
			count_note = 0;
		}
		
	 
}

void EFFECT_SPACE_GUN()
{
	if(i >= k){
		k++;
		i = 0;
	}
	else{
		i++;
	}
	if(k== 100){
		k=0;
		i = 0;
		*TIMER1_CMD = 2;
	}
	DAC_(i<<2);
	
}
void EFFECT_SPACE_JUMP()
{
	if(i >= 100-k){
		k++;
		i = 0;
	}
	else{
		i++;
	}
	if(k== 100){
		k=0;
		i = 0;
		*TIMER1_CMD = 2;
	}
	DAC_(i<<2);
	
}
void EFFECT()// MÅ JOBBES MED!!!!
{
	if(i >= k){
		k= k+2;
		i = 0;
	}
	else{
		i=i+2;
	}
	if(k== 500){
		k=0;
		i = 0;
		*TIMER1_CMD = 2;//stops timer1
	}
	DAC_(i<<2);
	
}
int PLAY_SONG1()
{
	if(count_note < period){	
		if(count_note < (period/4)*3){ //plays note shorter than total note lenght
			DAC_(*(Song1[note]+i)<<4);
		}
		count_note++;
		
		if(i >= *Song1_size[note]){i = 0;}
		else{i++;}
	}	
	else{
		count_note = 0;
		if(note == sizeof(*Song1)+2){ 
			note = 0;
			*TIMER1_CMD = 2;// stop timer1
			*SCR = 6;//enables sleep.
			return 0;
			
		}
		else{
			note++;
		}
		
	}
	return 1;
}
int PLAY_SONG2()
{
	if(count_note < period){
		if(count_note < (period/4)*3){
			DAC_(*(Song2[note]+i)<<4);}
		count_note++;
		
		if(i >= *Song2_size[note]){i = 0;}
		else{i++;}
	}	
	else{
		count_note = 0;
		if(note == sizeof(*Song2)){ 
			note = 0;
			*TIMER1_CMD = 2;
			*SCR = 6;
			return 0;
			
		}
		else{
			note++;
		}
		
	}
	return 1;
}
int PLAY_SONG3()
{
	if(count_note < period){
		if(count_note < (period/4)*3){
			DAC_(*(Song3[note]+i)<<4);}
		count_note++;
		
		if(i >= *Song3_size[note]){i = 0;}
		else{i++;}
	}	
	else{
		count_note = 0;
		if(note == sizeof(*Song3)+1){ 
			note = 0;
			*TIMER1_CMD = 2;
			*SCR = 6;
			return 0;
			
		}
		else{
			note++;
		}
		
	}
	return 1;
}
int PLAY_SONG4()
{
	if(count_note < period/2){
		if(count_note < (period/4)*3){
			DAC_(*(Song4[note]+i)<<4);}
		count_note++;
		
		if(i >= *Song4_size[note]){i = 0;}
		else{i++;}
	}	
	else{
		count_note = 0;
		if(note == sizeof(*Song4)){ 
			note = 0;
			*TIMER1_CMD = 2;
			*SCR = 6;
			return 0;
		}
		else{
			note++;
		}
		
	}
	return 1;
}
int PLAY_SONG5()
{
	if(count_note < period){
		if(count_note < (period/4)*3){
			DAC_(*(Song5[note]+i)<<4);}
		count_note++;
		
		if(i >= *Song5_size[note]){i = 0;}
		else{i++;}
	}	
	else{
		count_note = 0;
		if(note == sizeof(*Song5)){ 
			note = 0;
			*TIMER1_CMD = 2;
			*SCR = 6;
			return 0;
			
		}
		else{
			note++;
		}
		
	}
	return 1;
}
int PLAY_SONG6()
{
	if(count_note < period){
		if(count_note < (period/4)*3){
			DAC_(*(Song6[note]+i)<<4);}
		count_note++;
		
		if(i >= *Song6_size[note]){i = 0;}
		else{i++;}
	}	
	else{
		count_note = 0;
		if(note == 3){ 
			note = 0;
			*TIMER1_CMD = 2;
			*SCR = 6;
			return 0;
			
		}
		else{
			note++;
		}
		
	}
	return 1;
}
int PLAY_SONG7()
{
	if(count_note < period){
		if(count_note < (period/4)*3){
			DAC_(*(Song7[note]+i)<<4);}
		count_note++;
		
		if(i >= *Song7_size[note]){i = 0;}
		else{i++;}
	}	
	else{
		count_note = 0;
		if(note == sizeof(*Song7)){ 
			note = 0;
			*TIMER1_CMD = 2;
			*SCR = 6;
			return 0;
			
		}
		else{
			note++;
		}
		
	}
	return 1;
}
int PLAY_SONG8()
{
	if(count_note < period){
		if(count_note < (period/4)*3){
			DAC_(*(Song8[note]+i)<<4);}
		count_note++;
		
		if(i >= *Song8_size[note]){i = 0;}
		else{i++;}
	}	
	else{
		count_note = 0;
		if(note == 10){ 
			note = 0;
			*TIMER1_CMD = 2;
			*SCR = 6;
			return 0;
			
			
		}
		else{
			note++;
		}
		
	}
	return 1;
}

void DAC_(int data)// sends data to DAC
{	
				*DAC0_CH0DATA = data/2;
				*DAC0_CH1DATA = data/2;
}
