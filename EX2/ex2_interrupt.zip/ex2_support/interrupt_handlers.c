#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

#include "efm32gg.h"
#include "Sound.c"

//Function prototype
void DAC_(int data);
void EFFECT_SPACE_GUN();
void EFFECT_SPACE_JUMP();
void EFFECT_ZAP();
void sleep();
void setupDAC();
int PLAY_INTRO();
int PLAY_SONG(int** song,int** song_size);

int i = 0;
int k = 0;
int melody = 8;			//Melody to play. 8 = intro song. 
int note = 0;			
int count_note = 0;		//Counter for note lenght
int period = 44000/4;	//Sets how long to play a note

/*
 * Interrupt timer1 handler
 */
void __attribute__ ((interrupt)) TIMER1_IRQHandler()
{

	 *TIMER1_IFC = 1; 					  // clears the intterupt flag
	 
	 *GPIO_PA_DOUT = (*GPIO_PC_DIN << 8); //maps the LEDs to the right button
		switch(melody){
			case 0:
				EFFECT_SPACE_JUMP();
			break;
			case 1:
				EFFECT_SPACE_GUN();
			break;
			case 2:
				EFFECT_ZAP();
			break;
			case 3:
				PLAY_SONG(Song4,Song4_size);
			break;
			case 4:
				PLAY_SONG(Song5,Song5_size);
			break;
			case 5:
				PLAY_SONG(Song6,Song6_size);
			break;
			case 6:
				PLAY_SONG(Song7,Song7_size);
			break;
			case 7:
				PLAY_SONG(Song8,Song8_size);
			break;
			case 8:
				PLAY_SONG(Intro,Intro_size);
			break;
			}
}


/*
 * GPIO even pin interrupt handler 
 */
 
void __attribute__ ((interrupt)) GPIO_EVEN_IRQHandler()
{
	 *SCR = 0;				//makes sure the microcontroller does not go to sleep between timer interrupt.
	 setupDAC();			//Enables the DAC
	 *GPIO_IFC = *GPIO_IF; 	//clear interrupt flag
	 *TIMER1_CMD = 1; 		//start interrupt timer
	 	if(*GPIO_PC_DIN == 0b11111110)	//if SW1 is pressed
		{
			melody = 0;
			note = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111101)
		{
			melody = 1;	
			note = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111011)
		{	
			melody = 2;
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11110111)
		{	
			melody = 3;	
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11101111)
		{
			melody = 4;	
			note = 0;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11011111)
		{
			melody = 5;	
			note = 0;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b10111111)
		{	
			melody = 6;
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b01111111)
		{	
			melody = 7;
			note = 0;		
			count_note = 0;
		}
}

/*
 * GPIO odd pin interrupt handler 
 */
void __attribute__ ((interrupt)) GPIO_ODD_IRQHandler()
{
	 *SCR = 0;				//Makes sure the microcontroller does not go to sleep between timer interrupt.
	 setupDAC();			//Enables the DAC
	 *GPIO_IFC = *GPIO_IF; 	//clear interrupt flag
	 *TIMER1_CMD = 1; 		//start interrupt timer
	 	if(*GPIO_PC_DIN == 0b11111110)
		{
			melody = 0;
			note = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111101)
		{
			melody = 1;	
			note = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111011)
		{	
			melody = 2;
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11110111)
		{	
			melody = 3;	
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11101111)
		{
			melody = 4;	
			note = 0;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11011111)
		{
			melody = 5;	
			note = 0;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b10111111)
		{	
			melody = 6;
			note = 0;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b01111111)
		{	
			melody = 7;
			note = 0;		
			count_note = 0;
		}
		
	 
}
int PLAY_SONG(int** song,int** song_size) //Function to play melodies
{
	if(count_note < period){			//Sets the length of a note. 
		if(count_note < (period/4)*3){ 	//plays note shorter than total note lenght	
			DAC_(*(song[note]+i)<<4);	//Sends value to DAC. left bit shift to make it 12-bit.
		}
		count_note++;
		
		if(i >= *song_size[note]){
			i = 0;						//checks the lenght of the note
		}	
		else{
			i++;
		}
	}	
	else{
		count_note = 0;
		note++;
	}
	
	if(*(song[note]) != 127){ 			//Every note starts with 127. If the note starts with another value, its not a note. End song.
		note = 0;
		sleep();
		return 0;
		}
	return 0;
}
void EFFECT_SPACE_GUN()		//Sound effect
{
	if(i >= k){
		k++;
		i = 0;
	}
	else{
		i++;
	}
	if(k>= 100){
		k=0;
		i = 0;
		sleep();
	}
	else{
		DAC_(i<<2);
	}
	
}
void EFFECT_SPACE_JUMP()	//Sound effect
{
	if(i >= 100-k){
		k++;
		i = 0;
	}
	else{
		i++;
	}
	if(k>= 100){
		k=0;
		i = 0;
		sleep();
	}
	else{
		DAC_(i<<2);
	}
}
void EFFECT_ZAP()		//Sound effect
{
	if(i >= k){
		k= k+2;
		i = 0;
	}
	else{
		i=i+2;
	}
	if(k== 500){
		k=0;
		i = 0;
		sleep();
	}
	else{
		DAC_(i<<2);
	}
}

void DAC_(int data)// sends data to DAC
{	
	*DAC0_CH0DATA = data/4;
	*DAC0_CH1DATA = data/4;
}

void sleep() //Gets the microcontroller into sleep
{
	//Disable timer interrupt
	*TIMER1_CMD = 2;
	//Disable DAC
	*CMU_HFPERCLKEN0 &= ~(1<<17);
	*DAC0_CTRL = 0;
	*DAC0_CH0CTRL = 0;
	*DAC0_CH1CTRL = 0;
	//Enable sleep
	*SCR = 6;
}
