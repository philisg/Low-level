#include <stdint.h>
#include <stdbool.h>

#include "efm32gg.h"
#include "Sound.c"



void DAC_(int data);// sends data to DAC

/*
 * TIMER1 interrupt handler 
 */
int i = 0;
int n = 0;
int count_note = 0;;
void __attribute__ ((interrupt)) TIMER1_IRQHandler()
{

	/*
	 * TODO feed new samples to the DAC remember to clear the pending
	 * interrupt by writing 1 to TIMER1_IFC 
	 */
	 *TIMER1_IFC = 1; // clears the intterupt flag
	 count_note++;
	 *GPIO_PA_DOUT = (*GPIO_PC_DIN << 8);
		if(*GPIO_PC_DIN == 0b11111110)
		{
			n = 0;
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111101)
		{
			n = 1;	
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11111011)
		{	
			n = 2;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11110111)
		{	
			n = 3;			
			count_note = 0;
		}
		if(*GPIO_PC_DIN == 0b11101111)
		{
			n = 4;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b11011111)
		{
			n = 5;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b10111111)
		{	
			n = 6;		
			count_note = 0;
		}
		else if(*GPIO_PC_DIN == 0b01111111)
		{	
			n = 7;		
			count_note = 0;
		}
		
		if(count_note < 44000/10){
		DAC_(*(t4[n]+i)<<4);
		
		if(i >= *t4_size[n]){i = 0;}
		else{i++;}
		}
 
}

/*
 * GPIO even pin interrupt handler 
 */
void __attribute__ ((interrupt)) GPIO_EVEN_IRQHandler()
{
	/*
	 * TODO handle button pressed event, remember to clear pending
	 * interrupt 
	 */
}

/*
 * GPIO odd pin interrupt handler 
 */
void __attribute__ ((interrupt)) GPIO_ODD_IRQHandler()
{
	/*
	 * TODO handle button pressed event, remember to clear pending
	 * interrupt 
	 */
}


void DAC_(int data)// sends data to DAC
{	
				*DAC0_CH0DATA = data/2;
				*DAC0_CH1DATA = data/2;
}
