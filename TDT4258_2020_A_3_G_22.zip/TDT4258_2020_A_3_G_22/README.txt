driver-gampad.c file contains the gamepad-driver code and needs th eefm32gg.h file 
given in the support-files for exercise 3

